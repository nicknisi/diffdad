import { shared } from '../src/util';
import { lonely } from './lonely';

export const c = shared(3) + lonely;
