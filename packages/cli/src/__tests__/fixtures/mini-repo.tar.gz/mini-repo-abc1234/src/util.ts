export function shared(n: number): number {
  return n + 1;
}
