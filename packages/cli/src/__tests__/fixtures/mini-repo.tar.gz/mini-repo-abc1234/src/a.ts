import { shared } from './util';

export const a = shared(1);
