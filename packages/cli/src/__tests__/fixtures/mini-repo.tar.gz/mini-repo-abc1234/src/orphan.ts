import { lonely } from './lonely';

export const orphan = lonely;
