const { shared } = require('./util');

module.exports = shared(2);
